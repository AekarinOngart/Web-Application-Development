﻿namespace Gintuay.Models
{
    public class Addon
    {
        public int AddonId { get; set; }
        public string Add1 { get; set; }
        public int Price1 { get; set; }
        public string Add2 { get; set; }
        public int Price2 { get; set; }
    }
}
